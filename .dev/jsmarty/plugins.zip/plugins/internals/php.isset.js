
function isset(v){
	return !(v == null || typeof(v) == 'undefined');
};
