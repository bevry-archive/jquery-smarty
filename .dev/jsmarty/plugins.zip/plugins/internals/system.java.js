JSmarty.Classes.extend(JSmarty.System)
({
	
});